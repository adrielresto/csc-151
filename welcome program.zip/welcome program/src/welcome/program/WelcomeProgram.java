/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package welcome.program;
import javax.swing.JOptionPane;

/**
 *
 * @author restoa1637
 */
public class WelcomeProgram {

    public static void main(String[] args) {

        String name = askName();

        String welcomeMessage = createWelcomeMessage(name);

        JOptionPane.showMessageDialog(null, welcomeMessage);

        showGoodbyeMessage(name);

    }

    // Step 2: Method to ask for the user's name

    public static String askName() {

        return JOptionPane.showInputDialog("What is your name?");

    }

    // Step 3: Method to create a welcome message

    public static String createWelcomeMessage(String name) {

        return "Welcome, " + name + "! We're glad to have you here.";

    }

    // Step 4: Method to show a goodbye message

    public static void showGoodbyeMessage(String name) {

        JOptionPane.showMessageDialog(null, "Thank you, " + name + ". Goodbye!ツ ");

    }

}
